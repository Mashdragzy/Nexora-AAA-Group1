# Team changes, evening of 17 November 2026

AAA Group 1. Every file added or changed in this round, one sentence each.

## AI test bench (red team)
- `clearing-house-web3/apps/server/demo/emails/clear_fr.txt`, `trapped_fr.txt`, `trapped_signature.txt`, `over_cap.txt`, `other_manager.txt` (new): five synthetic test emails in English and French.
- `clearing-house-web3/apps/server/src/routes/bench.ts` (new): the eight bench cases with their legitimate order, `GET /bench`, `POST /bench/:id` (one agent call, mandate check, verdict) and the pure `judge` function.
- `clearing-house-web3/apps/web/src/components/BenchPanel.tsx` (new): the "AI test bench" tab with the score and one Run button per email.
- `clearing-house-web3/apps/web/src/App.tsx`, `components/Tabs.tsx`, `App.css`: new tab and styles.
- `clearing-house-web3/apps/web/src/api.ts`: bench calls and the audit trail URL.

## Plain-language refusals
- `clearing-house-web3/packages/engine/src/explain.ts` (new) and `src/index.ts`: `explainRefusal` turns each technical refusal into one plain sentence.
- `clearing-house-web3/apps/web/src/components/IntakePanel.tsx`, `OrdersTable.tsx`, `InstructionForm.tsx`: refusals shown with that sentence.

## Audit trail export
- `clearing-house-web3/apps/server/src/routes/audit.ts` (new): `GET /audit.csv`, every signed decision in time order with signer and signature or transaction hash.
- `clearing-house-web3/apps/web/src/components/Overview.tsx`: "Download the audit trail (CSV)" button.
- `clearing-house-web3/apps/server/src/app.ts`: registers the bench and audit routes.

## Tests and demo
- `clearing-house-web3/packages/engine/test/explain.test.ts`, `clearing-house-web3/apps/server/test/bench.test.ts` (new): 10 new tests (bench judgement, routes, audit CSV, explanations).
- `clearing-house-web3/scripts/demo-walkthrough.mjs`: also checks the audit CSV and opens the bench tab (no model call).
- `clearing-house-web3/scripts/demo-video.mjs`: new "AI test bench" scene; "How it is built" removed to keep the video under 5 min 30.

Checks: typecheck and lint clean, 128 tests passing (3 skipped: live model tests), walkthrough OK.
