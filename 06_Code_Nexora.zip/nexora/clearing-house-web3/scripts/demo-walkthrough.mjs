// npm run demo:walkthrough
//
// Automatic end-to-end check of the demo, exactly as a first-time user would click it:
// demo accounts, two mandates, two orders, a refused order, netting, approvals, settlement.
// It starts its own local stack, drives the page in Chrome (Playwright) and saves a
// screenshot of each step in ../docs-clearing-house-web3/walkthrough/.
// Exit code 0 means the whole flow works on this machine.
import { mkdirSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { chromium } from "playwright";
import { ROOT, startLocalStack } from "./local-stack.mjs";

const OUT_DIR = resolve(ROOT, "../docs-clearing-house-web3/walkthrough");
mkdirSync(OUT_DIR, { recursive: true });

const stack = await startLocalStack({
  participants: (accounts) => accounts.slice(2, 5),
  storeDir: mkdtempSync(join(tmpdir(), "nexora-walk-")),
  env: { VITE_DEMO_SIGNER: "1" },
  log: () => undefined,
});

// Uses the Chrome installed on the machine; falls back to Playwright's own Chromium.
const browser = await chromium.launch({ channel: "chrome" }).catch(() => chromium.launch());
const page = await browser.newPage({ viewport: { width: 1600, height: 1000 } });
let shot = 0;
const capture = async (name) => {
  shot += 1;
  const file = join(OUT_DIR, `${String(shot).padStart(2, "0")}-${name}.png`);
  await page.waitForTimeout(500);
  await page.screenshot({ path: file, fullPage: true });
  console.log(`[walkthrough] ${name}`);
};
const section = (n) => page.locator("section.card").nth(n - 1);
const expectText = async (text) => page.getByText(text, { exact: false }).first().waitFor({ timeout: 15_000 });

try {
  await page.goto(stack.webUrl, { waitUntil: "networkidle" });
  await expectText("First time here?");
  await capture("welcome");

  // Step 1: demo accounts
  await page.getByTestId("tab-participants").click();
  await page.getByTestId("use-demo").click();
  await expectText("Three demo accounts ready");
  await capture("demo-accounts");

  // Step 2: mandates for Manager A and Manager B
  await page.locator("summary", { hasText: "Sign a mandate" }).click();
  const mandateCard = section(2);
  for (const who of ["A", "B"]) {
    await mandateCard.locator("select").first().selectOption(who);
    await mandateCard.getByRole("button", { name: /Sign the mandate/ }).click();
    await mandateCard.getByText(`Manager ${who} signed and accepted`, { exact: false }).waitFor({ timeout: 15_000 });
  }
  await capture("mandates-signed");

  // Step 4: A subscribes 100 units, B redeems 40 units
  await page.getByTestId("tab-orders").click();
  const orderCard = section(4);
  const order = async (who, side, units) => {
    const selects = orderCard.locator("select");
    await selects.nth(0).selectOption(who);
    await selects.nth(1).selectOption(side);
    await orderCard.locator("input").nth(1).fill(String(units));
    await orderCard.getByRole("button", { name: /Sign the order/ }).click();
    await orderCard.getByText(/signed and accepted|refused by the mandate/).waitFor({ timeout: 15_000 });
  };
  await order("A", "BUY", 100);
  await order("B", "SELL", 40);
  await capture("orders-signed");

  // A refused order: far above Manager A's cash cap
  await order("A", "BUY", 1_000_000);
  await expectText("Refused by mandate");
  await capture("order-refused-by-mandate");

  // Step 6: netting lot, both approvals, settlement on chain
  await page.getByTestId("tab-settlement").click();
  const settleCard = section(6);
  await settleCard.getByRole("button", { name: /Settle cycle/ }).click();
  await expectText("Waiting for approvals");
  for (let i = 0; i < 2; i += 1) {
    await settleCard.getByRole("button", { name: /Sign approval/ }).first().click();
    await page.waitForTimeout(800);
  }
  await expectText("Settled on chain");
  await capture("lot-settled");

  // The overview after the run: flow, key figures, gross against net, activity
  await page.getByTestId("tab-overview").click();
  await expectText("Cash saved by netting");
  await capture("overview-after-settlement");

  // Audit trail export: one CSV line per signed decision (2 mandates, 3 orders, 2 approvals, 1 settlement)
  const auditUrl = await page.getByTestId("audit-csv").getAttribute("href");
  const audit = await (await page.request.get(auditUrl)).text();
  const lines = audit.trim().split(String.fromCharCode(10));
  if (!lines[0].startsWith("time,event") || lines.length < 9) throw new Error(`audit trail has ${lines.length} lines`);
  console.log(`[walkthrough] audit trail: ${lines.length - 1} signed events`);

  // AI test bench: the eight cases are listed (no model call here, to keep the free quota)
  await page.getByTestId("tab-bench").click();
  await expectText("Fake system notice");
  await capture("ai-test-bench");
  console.log("[walkthrough] OK: the full flow works");
} catch (error) {
  await capture("failure");
  console.error("[walkthrough] FAILED:", error.message);
  process.exitCode = 1;
} finally {
  await browser.close();
  stack.stop();
}
