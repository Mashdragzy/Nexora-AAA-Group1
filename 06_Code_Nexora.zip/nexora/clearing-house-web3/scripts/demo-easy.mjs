// npm run demo:easy
//
// The easiest way to try Nexora: no Ledger, no wallet, no testnet, no key needed.
//   1. checks that Node and Foundry (anvil, forge) are installed,
//   2. starts a local blockchain (anvil) and deploys the contracts,
//   3. starts the API server and the web dashboard,
//   4. opens http://localhost:5173 with the "Use demo accounts" button enabled.
// The dashboard starts empty: follow the 4-step guide of the Overview tab.
// Set DEMO_PREFILLED=1 to start with two mandates, two orders and one settled lot.
// Ctrl+C stops everything.
import { spawn, spawnSync } from "node:child_process";
import { existsSync, mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { privateKeyToAccount } from "viem/accounts";
import { instructionToText, mandateToText } from "@chw3/protocol";
import { ROOT, startLocalStack } from "./local-stack.mjs";

const ENV_FILE = resolve(ROOT, ".env");
if (existsSync(ENV_FILE)) process.loadEnvFile(ENV_FILE);

// --- 1. prerequisites -------------------------------------------------------------
function has(command) {
  return spawnSync(command, ["--version"], { shell: true, stdio: "ignore" }).status === 0;
}
const nodeMajor = Number(process.versions.node.split(".")[0]);
if (nodeMajor < 22) {
  console.error(`[nexora] Node ${process.versions.node} found, Node 22 or newer is required: https://nodejs.org`);
  process.exit(1);
}
if (!has("anvil") || !has("forge")) {
  console.error("[nexora] Foundry is missing (commands anvil and forge). Install it, then run this command again:");
  console.error("         https://book.getfoundry.sh/getting-started/installation");
  console.error("         Windows without WSL: unzip the foundry_*_win32_amd64.zip release and add its folder to PATH.");
  process.exit(1);
}

// --- 2 and 3. local chain, contracts, server, dashboard ------------------------------
console.log("[nexora] starting the local blockchain, the server and the dashboard (about 20 seconds)...");
const stack = await startLocalStack({
  // anvil accounts 2, 3 and 4 play Manager A, Manager B and Depositary C (same keys as the web demo signer)
  participants: (accounts) => accounts.slice(2, 5),
  storeDir: mkdtempSync(join(tmpdir(), "nexora-demo-")),
  env: { VITE_DEMO_SIGNER: "1" },
  log: (line) => (process.env.DEMO_VERBOSE ? console.log(line) : undefined),
});
const stopAll = () => {
  stack.stop();
  process.exit(0);
};
process.on("SIGINT", stopAll);
process.on("SIGTERM", stopAll);

// --- optional prefilled state (used for screenshots and quick reviews) -----------------
if (process.env.DEMO_PREFILLED === "1") {
  const UNIT = 10n ** 6n;
  const CYCLE = new Date().toISOString().slice(0, 10);
  const [, , keyA, keyB] = stack.keys;
  const api = async (path, body) => {
    const res = await fetch(stack.serverUrl + path, { method: body ? "POST" : "GET", headers: { "content-type": "application/json" }, body: body && JSON.stringify(body) });
    if (!res.ok) throw new Error(`${path}: ${res.status} ${await res.text()}`);
    return res.json();
  };
  const managers = [
    { account: privateKeyToAccount(keyA), name: "Manager A", id: "a1b2c3", side: "BUY", units: 100n },
    { account: privateKeyToAccount(keyB), name: "Manager B", id: "d4e5f6", side: "SELL", units: 40n },
  ];
  for (const m of managers) {
    const mandate = { participant: m.account.address, participantName: m.name, allowedFunds: ["Fund F"], maxCashPerCycle: 5_000_000n * UNIT, allowedSides: ["BUY", "SELL"], nonce: 1 };
    await api("/mandates", { mandate: { ...mandate, maxCashPerCycle: mandate.maxCashPerCycle.toString() }, signature: await m.account.signMessage({ message: mandateToText(mandate) }) });
    const instruction = { id: m.id, cycleId: CYCLE, fund: stack.deployer, participant: m.account.address, side: m.side, shares: m.units * UNIT };
    const payload = { instruction, fundName: "Fund F", participantName: m.name, nonce: 1 };
    const signature = await m.account.signMessage({ message: instructionToText(payload) });
    await api("/instructions", { ...payload, instruction: { ...instruction, shares: instruction.shares.toString() }, signature, origin: "manual" });
  }
  const lot = await api(`/cycles/${CYCLE}/lots`, { mode: "netting" });
  for (const m of managers) await api(`/lots/${lot.id}/approvals`, { participant: m.account.address, signature: await m.account.signMessage({ message: lot.texts[m.account.address] }) });
  console.log("[nexora] prefilled: two mandates, two orders, one netted lot settled on the local chain");
}

// --- 4. open the dashboard -------------------------------------------------------------
console.log("");
console.log(`[nexora] ready: ${stack.webUrl}`);
console.log("[nexora] in the page, click “Use demo accounts”, then follow the 4-step guide. Ctrl+C here to stop.");
if (!process.env.DEMO_NO_BROWSER) {
  const opener = process.platform === "win32" ? ["cmd", ["/c", "start", "", stack.webUrl]] : process.platform === "darwin" ? ["open", [stack.webUrl]] : ["xdg-open", [stack.webUrl]];
  spawn(opener[0], opener[1], { stdio: "ignore", detached: true }).unref();
}
