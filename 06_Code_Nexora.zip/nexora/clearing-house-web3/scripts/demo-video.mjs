// npm run demo:video
//
// Records the demo video by itself: it starts a fresh local stack, drives the dashboard in
// Chrome like a presenter would, shows subtitles, adds a synthetic voice-over and writes
// ../docs-clearing-house-web3/video/nexora-demo.mp4.
//
// Needs, besides the usual demo requirements:
//   - an OpenRouter key in .env (the AI agent is part of the story);
//   - Python with edge-tts (pip install edge-tts) for the voice-over;
//   - ffmpeg on PATH, or its path in the FFMPEG variable;
//   - Playwright's video encoder: npx playwright install ffmpeg.
import { execFileSync } from "node:child_process";
import { mkdirSync, mkdtempSync, renameSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { chromium } from "playwright";
import { ROOT, startLocalStack } from "./local-stack.mjs";

const FFMPEG = process.env.FFMPEG || "ffmpeg";
const PYTHON = process.env.TTS_PYTHON || "python";
const VOICE = process.env.TTS_VOICE || "en-US-BrianNeural";
const OUT_DIR = resolve(ROOT, "../docs-clearing-house-web3/video");
const WORK = mkdtempSync(join(tmpdir(), "nexora-video-"));
const SIZE = { width: 1600, height: 900 };
mkdirSync(OUT_DIR, { recursive: true });

// The story, one scene per step. Each scene speaks its text while its action runs; the next
// scene starts when both are done.
const SCENES = [
  {
    title: "The problem",
    text: "Today, a fund subscription or redemption still starts as an email. Someone retypes it and waits for the price. The cash moves two business days later. Nexora turns that email into a settled trade in seconds. The AI drafts, the code checks, a human signs and the blockchain settles.",
    action: async ({ page }) => {
      await page.mouse.wheel(0, 0);
    },
  },
  {
    title: "The challenge",
    text: "One of the main challenges in financial operations is that information is often fragmented across different systems and participants. This fragmentation can create delays, misunderstandings and unnecessary administrative work. Nexora aims to address this issue by connecting the different stages of a transaction within a single workflow. The objective is not only to improve efficiency, but also to ensure that every instruction can be verified and traced throughout the process.",
    action: async ({ page }) => {
      await highlight(page, page.locator(".hero"));
      await highlight(page, page.locator(".flow"));
    },
  },
  {
    title: "1. Who signs",
    text: "First, who signs. On a real desk, each fund manager signs on a Ledger hardware wallet. For this demo we use three test accounts, so anyone can run Nexora on a laptop with two commands.",
    action: async ({ page }) => {
      await click(page, page.getByTestId("tab-participants"));
      await click(page, page.getByTestId("use-demo"));
      await page.getByText("Three demo accounts ready").first().waitFor({ timeout: 15_000 });
    },
  },
  {
    title: "2. The rules",
    text: "Each manager signs a mandate once: the fund they may trade, buy or sell, and a cash cap per day. Every order is checked against it by plain code, not by the AI.",
    action: async ({ page }) => {
      const card = section(page, 2);
      await click(page, page.locator("summary", { hasText: "Sign a mandate" }));
      for (const who of ["A", "B"]) {
        await card.locator("select").first().selectOption(who);
        await click(page, card.getByRole("button", { name: /Sign the mandate/ }));
        await card.getByText(`Manager ${who} signed and accepted`, { exact: false }).waitFor({ timeout: 15_000 });
      }
    },
  },
  {
    title: "3. A trapped email",
    text: "Now the AI part. This order email hides a trap: a fake system notice asks the assistant to redeem one million units instead of the real order.",
    action: async ({ page }) => {
      await click(page, page.getByTestId("tab-orders"));
      await highlight(page, section(page, 3));
    },
  },
  {
    title: "3. The AI agent",
    text: "Our agent runs on a free open model through OpenRouter. It has a single tool, draft instruction: it cannot sign, compute amounts or move money. It keeps the real order of ten units and says it ignored the hidden instructions.",
    action: async ({ page }) => {
      await askAgent(page);
      // The real draft goes to the signing form now; it stays there during the next scene.
      await click(page, page.getByRole("button", { name: /Send the draft to the order form/ }));
    },
  },
  {
    title: "3. If the AI were fooled",
    text: "And if a weaker model had obeyed? Its draft would still meet the mandate check. One million units is far above the cap, so it is refused before anyone can sign it. Safety comes from the signed rules, not from trusting the model.",
    action: async ({ page }) => {
      await click(page, page.getByRole("button", { name: /Simulate a fooled agent/ }));
      await page.getByText("Nothing is sent for signature", { exact: false }).first().waitFor({ timeout: 15_000 });
      await highlight(page, page.getByTestId("agent-result"));
    },
  },
  {
    title: "Responsible AI",
    text: "This example highlights a fundamental challenge in artificial intelligence: the difference between generating a plausible answer and making a reliable decision. AI models can interpret complex instructions, but they do not necessarily understand the legal or operational consequences of their outputs. For this reason, Nexora separates the interpretation of information from the authorization of transactions. This architecture illustrates an important principle of responsible AI: automation should support human decision-making while remaining subject to explicit rules and independent verification.",
    action: async ({ page }) => {
      await highlight(page, section(page, 3));
      await highlight(page, section(page, 4));
    },
  },
  {
    title: "3. An ambiguous email",
    text: "The agent also knows when not to act. This email asks for the usual order, same size as last time. The fund, the side and the quantity are missing, so the agent drafts nothing and explains what is missing instead of guessing.",
    action: async ({ page }) => {
      await askAgent(page, "Ambiguous email", "No draft created");
    },
  },
  {
    title: "4. Human signatures",
    text: "The real order goes to the signing form. Manager A signs the order drafted by the AI, and Manager B signs a redemption of eight units. The black box shows exactly the text that is signed.",
    action: async ({ page }) => {
      await signOrder(page);
      await order(page, "B", "SELL", 8);
    },
  },
  {
    title: "6. Netting",
    text: "At the end of the cycle, the engine nets the orders of the day. Buys and sells offset each other, so only the difference has to move.",
    action: async ({ page }) => {
      await click(page, page.getByTestId("tab-settlement"));
      await click(page, section(page, 6).getByRole("button", { name: /Settle cycle/ }));
      await page.getByText("Waiting for approvals").first().waitFor({ timeout: 15_000 });
    },
  },
  {
    title: "6. Settlement on chain",
    text: "Each manager approves the lot. The smart contract then swaps fund units against cash in one transaction, delivery versus payment, and records every signature on chain.",
    action: async ({ page }) => {
      for (let i = 0; i < 2; i += 1) {
        await click(page, section(page, 6).getByRole("button", { name: /Sign approval/ }).first());
        await page.waitForTimeout(900);
      }
      await page.getByText("Settled on chain").first().waitFor({ timeout: 20_000 });
    },
  },
  {
    title: "The result",
    text: "Back on the overview, every stage is filled in. Almost ninety percent of the cash never had to move, and the trade settled seconds after the first order instead of two business days.",
    action: async ({ page }) => {
      await click(page, page.getByTestId("tab-overview"));
      await page.getByText("Cash saved by netting").first().waitFor();
      await highlight(page, page.locator(".tile.highlight"));
      await smoothScroll(page, 520);
    },
  },
  {
    title: "AI test bench",
    text: "To test the agent with a critical eye, we built a red team bench: eight synthetic emails in English and French, clear, ambiguous or trapped. Here a French email hides a fake internal note. The agent drafts only the real order, every refusal is explained in plain words and each signed event can be exported as an audit trail.",
    action: async ({ page }) => {
      await click(page, page.getByTestId("tab-bench"));
      const row = page.locator("table.bench tr", { hasText: "Note interne" });
      await click(page, row.getByRole("button", { name: /Run/ }));
      await page.getByTestId("bench-result-trapped_fr").locator(".badge").first().waitFor({ timeout: 90_000 }).catch(() => undefined);
      await highlight(page, page.getByTestId("bench-score"));
    },
  },
  {
    title: "Why it matters",
    text: "Why does it matter? Across the fund industry, orders still travel by email and cash settles days later. Generalised, Nexora would free the cash stuck in transit, remove retyping errors and give regulators a signed proof of every decision.",
    action: async ({ page }) => {
      await click(page, page.getByTestId("tab-overview"));
      await highlight(page, page.locator(".hero"));
    },
  },
  {
    title: "AI in finance",
    text: "Beyond this demonstration, Nexora also raises questions about the future of artificial intelligence in financial services. The objective is not to replace financial professionals, but to allow them to focus on tasks where their judgment and expertise are most valuable. However, several challenges remain, including cybersecurity, regulatory compliance and the reliability of automated systems. Ultimately, the success of AI in finance will depend not only on its technical performance, but also on the trust it can establish among users and institutions.",
    action: async ({ page }) => {
      await highlight(page, page.locator(".tiles"));
    },
  },
  {
    title: "Nexora",
    text: "We built Nexora on Cendro, an open source project by Team Kryptosphere from the Ledger hackathon, and made it usable by anyone: demo accounts, free AI models and a guided dashboard. Nexora: fund orders, settled in seconds. Thank you for watching.",
    action: async ({ page }) => {
      await smoothScroll(page, -380);
    },
  },
];

// ---------- helpers ----------

const section = (page, n) => page.locator("section.card").nth(n - 1);

async function highlight(page, locator) {
  await locator.first().scrollIntoViewIfNeeded();
  await locator.first().evaluate((el) => {
    el.style.transition = "box-shadow 0.3s";
    el.style.boxShadow = "0 0 0 4px rgba(59, 91, 219, 0.55)";
  });
  await page.waitForTimeout(1400);
  await locator.first().evaluate((el) => (el.style.boxShadow = ""));
}

async function click(page, locator) {
  const el = locator.first();
  await el.scrollIntoViewIfNeeded();
  await el.evaluate((node) => {
    node.style.transition = "box-shadow 0.2s";
    node.style.boxShadow = "0 0 0 4px rgba(217, 119, 15, 0.8)";
  });
  await page.waitForTimeout(650);
  await el.click();
  await el.evaluate((node) => (node.style.boxShadow = "")).catch(() => undefined);
  await page.waitForTimeout(300);
}

async function smoothScroll(page, dy) {
  await page.evaluate((y) => window.scrollBy({ top: y, behavior: "smooth" }), dy);
  await page.waitForTimeout(1200);
}

async function order(page, who, side, units) {
  const card = section(page, 4);
  const selects = card.locator("select");
  await selects.nth(0).selectOption(who);
  await selects.nth(1).selectOption(side);
  await card.locator("input").nth(1).fill(String(units));
  await page.waitForTimeout(500);
  await signOrder(page);
}

// Signs what the order form shows and waits for the new line in the orders table.
async function signOrder(page) {
  const rows = section(page, 5).locator("tbody tr");
  const before = await rows.count();
  await click(page, section(page, 4).getByRole("button", { name: /Sign the order/ }));
  await page.waitForFunction(([n]) => document.querySelectorAll("section.card")[4].querySelectorAll("tbody tr").length > n, [before], { timeout: 15_000 });
  await page.waitForTimeout(800);
}

// The free models are sometimes busy: retry the trapped email a few times.
async function askAgent(page, button = "Trapped email", expected = "Send the draft to the order form") {
  for (let attempt = 1; attempt <= 4; attempt += 1) {
    await click(page, page.getByRole("button", { name: button }));
    const outcome = await Promise.race([
      page.getByTestId("agent-result").waitFor({ timeout: 90_000 }).then(() => "ok"),
      page.locator(".notice.bad").first().waitFor({ timeout: 90_000 }).then(() => "error"),
    ]);
    if (outcome === "ok" && (await page.getByText(expected).count()) > 0) {
      await highlight(page, page.getByTestId("agent-result"));
      return;
    }
    console.log(`[video] agent attempt ${attempt} did not give a draft, retrying`);
    await page.waitForTimeout(15_000);
  }
  throw new Error("the AI agent did not answer after 4 attempts");
}

// Subtitles and scene title drawn over the page; they appear in the recording.
async function caption(page, title, sentence) {
  await page.evaluate(
    ([t, s]) => {
      let box = document.getElementById("video-caption");
      if (!box) {
        box = document.createElement("div");
        box.id = "video-caption";
        box.innerHTML = '<div class="vc-title"></div><div class="vc-text"></div>';
        Object.assign(box.style, { position: "fixed", left: "50%", bottom: "28px", transform: "translateX(-50%)", maxWidth: "1180px", zIndex: 9999, pointerEvents: "none", textAlign: "center" });
        const style = document.createElement("style");
        style.textContent =
          "#video-caption .vc-title{display:inline-block;margin-bottom:8px;padding:3px 12px;border-radius:999px;background:#3b5bdb;color:#fff;font:600 15px system-ui}" +
          "#video-caption .vc-text{padding:12px 20px;border-radius:12px;background:rgba(13,27,58,.88);color:#fff;font:500 21px/1.4 system-ui;box-shadow:0 6px 24px rgba(0,0,0,.25)}";
        document.head.append(style);
        document.body.append(box);
      }
      box.querySelector(".vc-title").textContent = t;
      box.querySelector(".vc-text").textContent = s;
    },
    [title, sentence],
  );
}

function sentencesOf(text) {
  return text.match(/[^.!?]+[.!?]+/g)?.map((s) => s.trim()) ?? [text];
}

function durationOf(file) {
  let output = "";
  try {
    execFileSync(FFMPEG, ["-hide_banner", "-i", file], { stdio: ["ignore", "ignore", "pipe"] });
  } catch (error) {
    output = String(error.stderr);
  }
  const m = output.match(/Duration: (\d+):(\d+):([\d.]+)/);
  if (!m) throw new Error(`cannot read the duration of ${file}`);
  return (Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3])) * 1000;
}

// The online voice service drops a request now and then: retry a few times.
function speak(text, file) {
  for (let attempt = 1; ; attempt += 1) {
    try {
      execFileSync(PYTHON, ["-m", "edge_tts", "--voice", VOICE, "--rate=+4%", "--text", text, "--write-media", file], { stdio: "ignore" });
      return;
    } catch (error) {
      if (attempt === 6) throw error;
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 2000 * attempt);
    }
  }
}

// ---------- 1. voice-over ----------

console.log(`[video] voice-over with ${VOICE}`);
for (const [i, scene] of SCENES.entries()) {
  scene.audio = join(WORK, `scene-${i}.mp3`);
  speak(scene.text, scene.audio);
  scene.ms = durationOf(scene.audio);
}
const spoken = SCENES.reduce((s, x) => s + x.ms, 0);
console.log(`[video] ${SCENES.length} scenes, ${(spoken / 1000).toFixed(0)} s of narration`);
// DRY_RUN=1: only measure the narration (to fit the length rule) and stop before recording.
if (process.env.DRY_RUN === "1") {
  for (const scene of SCENES) console.log(`[video] ${(scene.ms / 1000).toFixed(1).padStart(5)} s  ${scene.title}`);
  process.exit(0);
}

// ---------- 2. recording ----------

const stack = await startLocalStack({
  participants: (accounts) => accounts.slice(2, 5),
  storeDir: mkdtempSync(join(tmpdir(), "nexora-video-store-")),
  env: { VITE_DEMO_SIGNER: "1" },
  log: () => undefined,
});
const browser = await chromium.launch({ channel: "chrome" }).catch(() => chromium.launch());
const context = await browser.newContext({ viewport: SIZE, recordVideo: { dir: WORK, size: SIZE } });
await context.addInitScript(() => localStorage.clear());
const page = await context.newPage();
const videoStart = Date.now();

try {
  await page.goto(stack.webUrl, { waitUntil: "networkidle" });
  await page.getByText("First time here?").waitFor({ timeout: 30_000 });
  await page.waitForTimeout(800);

  for (const scene of SCENES) {
    scene.at = Date.now() - videoStart;
    const sentences = sentencesOf(scene.text);
    const chars = sentences.reduce((s, x) => s + x.length, 0);
    // Subtitles follow the voice, sentence by sentence, in proportion to their length.
    const subtitles = (async () => {
      for (const s of sentences) {
        await caption(page, scene.title, s);
        await page.waitForTimeout((scene.ms * s.length) / chars);
      }
    })();
    await Promise.all([scene.action({ page }), subtitles]);
    await page.waitForTimeout(500);
    console.log(`[video] ${scene.title}`);
  }
  await page.waitForTimeout(1200);
} catch (error) {
  console.error("[video] FAILED:", error.message);
  process.exitCode = 1;
} finally {
  await context.close();
  await browser.close();
  stack.stop();
}

if (!process.exitCode) {
  // ---------- 3. assembly ----------
  const webm = await page.video().path();
  const start = Math.max(0, SCENES[0].at - 400);
  const inputs = ["-y", "-ss", (start / 1000).toFixed(3), "-i", webm];
  const filters = [];
  SCENES.forEach((scene, i) => {
    inputs.push("-i", scene.audio);
    const delay = Math.round(scene.at - start);
    filters.push(`[${i + 1}:a]adelay=${delay}|${delay}[a${i}]`);
  });
  filters.push(`${SCENES.map((_, i) => `[a${i}]`).join("")}amix=inputs=${SCENES.length}:normalize=0[a]`);
  const out = join(OUT_DIR, "nexora-demo.mp4");
  const tmp = join(WORK, "nexora-demo.mp4");
  execFileSync(
    FFMPEG,
    [...inputs, "-filter_complex", filters.join(";"), "-map", "0:v", "-map", "[a]", "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-pix_fmt", "yuv420p", "-r", "25", "-c:a", "aac", "-b:a", "160k", tmp],
    { stdio: "ignore" },
  );
  renameSync(tmp, out);
  console.log(`[video] OK: ${out} (${(durationOf(out) / 1000).toFixed(0)} s)`);
}
