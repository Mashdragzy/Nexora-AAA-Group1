import { describe, expect, it } from "vitest";
import { explainRefusal } from "../src/explain.ts";

describe("explainRefusal", () => {
  it("explains a single order above the cap with readable amounts", () => {
    expect(explainRefusal("105000000 USDC is above the signed cap of 5000000 USDC per cycle")).toBe(
      "This order is worth 105,000,000 USDC, above the 5,000,000 USDC per cycle that the manager's signed mandate allows.",
    );
  });

  it("explains a cap reached with earlier orders of the cycle", () => {
    expect(explainRefusal("5250000 USDC in this cycle, including 10500 USDC for this order, is above the signed cap of 5000000 USDC per cycle")).toBe(
      "With this order the manager would commit 5,250,000 USDC in the cycle (10,500 USDC for this order), above the 5,000,000 USDC cap they signed.",
    );
  });

  it("explains missing mandate, wrong fund, wrong side and unknown names", () => {
    expect(explainRefusal("no signed mandate for this participant")).toContain("has not signed a mandate");
    expect(explainRefusal("Fund Z is not in the allowed funds (Fund F)")).toBe("The signed mandate only allows Fund F, not Fund Z.");
    expect(explainRefusal("redeem is not an allowed side (allowed: subscribe)")).toBe("The signed mandate does not allow the manager to redeem (allowed: subscribe).");
    expect(explainRefusal("unknown participant Manager Z")).toBe("Manager Z is not a participant known to the clearing house.");
  });

  it("returns an unknown reason unchanged", () => {
    expect(explainRefusal("something new")).toBe("something new");
  });
});
