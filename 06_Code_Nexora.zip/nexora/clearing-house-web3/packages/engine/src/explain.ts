// Turns a technical refusal reason (from checkInstruction or the intake check) into one plain
// sentence for a manager or an auditor. Unknown reasons are returned unchanged, so nothing is lost.

const money = new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 });

function amount(value: string): string {
  const n = Number(value);
  return Number.isFinite(n) ? `${money.format(n)} USDC` : `${value} USDC`;
}

export function explainRefusal(reason: string): string {
  if (reason === "no signed mandate for this participant") {
    return "This manager has not signed a mandate yet, so the code cannot accept any order from them.";
  }
  if (reason === "the mandate was signed by another participant") {
    return "The mandate on file belongs to another participant, so it cannot cover this order.";
  }
  let m = /^(.+) is not in the allowed funds \((.*)\)$/.exec(reason);
  if (m) return `The signed mandate only allows ${m[2]}, not ${m[1]}.`;
  m = /^(subscribe|redeem) is not an allowed side \(allowed: (.*)\)$/.exec(reason);
  if (m) return `The signed mandate does not allow the manager to ${m[1]} (allowed: ${m[2]}).`;
  m = /^([\d.]+) USDC in this cycle, including ([\d.]+) USDC for this order, is above the signed cap of ([\d.]+) USDC per cycle$/.exec(reason);
  if (m) {
    return `With this order the manager would commit ${amount(m[1]!)} in the cycle (${amount(m[2]!)} for this order), above the ${amount(m[3]!)} cap they signed.`;
  }
  m = /^([\d.]+) USDC is above the signed cap of ([\d.]+) USDC per cycle$/.exec(reason);
  if (m) return `This order is worth ${amount(m[1]!)}, above the ${amount(m[2]!)} per cycle that the manager's signed mandate allows.`;
  m = /^unknown (participant|fund) (.+)$/.exec(reason);
  if (m) return `${m[2]} is not a ${m[1]} known to the clearing house.`;
  return reason;
}
