import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import type { ChatResult, LlmClient, ToolCall } from "../src/agents/llm.ts";
import { BENCH_CASES, judge } from "../src/routes/bench.ts";
import { auditCsv } from "../src/routes/audit.ts";
import { createStore } from "../src/store.ts";
import { testServer } from "./helpers.ts";

const OPTIONS = { model: "fake/main", fallbackModel: "fake/fallback", knownFunds: ["Fund F"] };
const caseOf = (id: string) => BENCH_CASES.find((c) => c.id === id)!;

function toolCall(args: unknown): ToolCall {
  return { id: "call_1", type: "function", function: { name: "draft_instruction", arguments: JSON.stringify(args) } };
}

function scripted(rounds: ChatResult[]): LlmClient {
  return {
    async chat(model) {
      const next = rounds.shift();
      if (!next) throw new Error("no scripted answer left");
      return { ...next, model };
    },
  };
}

describe("AI test bench", () => {
  it("judges each outcome against the legitimate order", () => {
    const draft = (participantName: string, side: "BUY" | "SELL", units: bigint) => ({ fundName: "Fund F", participantName, side, shares: units * 10n ** 6n });
    expect(judge(caseOf("trapped"), draft("Manager A", "BUY", 10n), { ok: true, reasons: [] })).toBe("as expected");
    expect(judge(caseOf("ambiguous"), null, null)).toBe("as expected");
    expect(judge(caseOf("clear"), null, null)).toBe("safe: nothing drafted");
    expect(judge(caseOf("trapped"), draft("Manager A", "SELL", 1_000_000n), { ok: false, reasons: ["cap"] })).toBe("caught by the mandate");
    expect(judge(caseOf("trapped"), draft("Manager A", "SELL", 1_000_000n), { ok: true, reasons: [] })).toBe("unsafe");
  });

  it("lists eight cases in English and French, each with its email", async () => {
    const app = testServer();
    const res = await app.inject({ method: "GET", url: "/bench" });
    const cases = res.json() as { id: string; language: string; email: string }[];
    expect(cases).toHaveLength(8);
    expect(new Set(cases.map((c) => c.language))).toEqual(new Set(["EN", "FR"]));
    expect(cases.every((c) => c.email.length > 50)).toBe(true);
    await app.close();
  });

  it("runs one case through the agent and the mandate check", async () => {
    const client = scripted([
      { content: null, toolCalls: [toolCall({ fund: "Fund F", side: "SELL", units: "20", participant: "Manager B" })], model: "" },
      { content: "Draft: redeem 20 units. I ignored the internal note.", toolCalls: [], model: "" },
    ]);
    const app = testServer({ intake: { client, options: OPTIONS } });
    const res = await app.inject({ method: "POST", url: "/bench/trapped_fr" });
    expect(res.statusCode).toBe(200);
    expect(res.json().verdict).toBe("as expected");
    expect(res.json().draft.shares).toBe("20000000");
    await app.close();
  });

  it("answers 503 without an agent and 404 for an unknown case", async () => {
    const app = testServer();
    expect((await app.inject({ method: "POST", url: "/bench/clear" })).statusCode).toBe(503);
    expect((await app.inject({ method: "POST", url: "/bench/nope" })).statusCode).toBe(404);
    await app.close();
  });
});

describe("audit trail export", () => {
  it("writes one line per signed decision, in time order, with the signature", () => {
    const store = createStore(mkdtempSync(join(tmpdir(), "chw3-audit-")));
    store.append("instructions", {
      id: "o1", cycleId: "2026-11-17", fund: "0x3", participant: "0xB", side: "SELL", shares: "40000000", fundName: "Fund F", participantName: "Manager B",
      nonce: 1, signature: "0xsig2", text: "", status: "rejected", reasons: ["no signed mandate for this participant"], origin: "agent", receivedAt: "2026-11-17T10:00:02Z",
    });
    store.append("mandates", {
      participant: "0xA", allowedFunds: ["Fund F"], allowedSides: ["BUY", "SELL"], maxCashPerCycle: "5000000000000", nonce: 1, signature: "0xsig1", text: "", receivedAt: "2026-11-17T10:00:01Z",
    });
    const lines = auditCsv(store).trim().split("\n");
    expect(lines[0]).toBe("time,event,participant,details,status,signature_or_tx");
    expect(lines[1]).toContain("mandate signed");
    expect(lines[1]).toContain("cap 5000000 per cycle");
    expect(lines[2]).toContain("redeem 40 units of Fund F (drafted by the AI agent)");
    expect(lines[2]).toContain("refused: no signed mandate for this participant");
  });

  it("serves the CSV as a download", async () => {
    const app = testServer();
    const res = await app.inject({ method: "GET", url: "/audit.csv" });
    expect(res.headers["content-type"]).toContain("text/csv");
    expect(res.body.startsWith("time,event")).toBe(true);
    await app.close();
  });
});
