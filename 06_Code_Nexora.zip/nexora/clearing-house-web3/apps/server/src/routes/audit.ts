import type { FastifyInstance } from "fastify";
import { formatUnits } from "viem";
import { CASH_DECIMALS, SHARE_DECIMALS } from "@chw3/engine";
import type { Store } from "../store.ts";
import { listInstructions } from "./instructions.ts";
import { listLots } from "./lots.ts";
import { listMandates } from "./mandates.ts";

// Audit trail export: every signed decision of the session, in time order, as a CSV file that a
// compliance officer or an auditor can open in Excel. Each line keeps the signer and the signature,
// so anyone can check it against the exact signed text.

const HEADER = ["time", "event", "participant", "details", "status", "signature_or_tx"];

function cell(value: string): string {
  return /[",\n;]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
}

export function auditRows(store: Store): string[][] {
  const rows: string[][] = [];
  for (const m of listMandates(store)) {
    const cap = formatUnits(BigInt(m.maxCashPerCycle), CASH_DECIMALS);
    rows.push([m.receivedAt, "mandate signed", m.participant, `funds ${m.allowedFunds.join(" / ")}; sides ${m.allowedSides.join(" / ")}; cap ${cap} per cycle`, "accepted", m.signature]);
  }
  for (const o of listInstructions(store)) {
    const units = formatUnits(BigInt(o.shares), SHARE_DECIMALS);
    const details = `${o.side === "BUY" ? "subscribe" : "redeem"} ${units} units of ${o.fundName} (${o.origin === "agent" ? "drafted by the AI agent" : "typed by hand"})`;
    const status = o.status === "rejected" ? `refused: ${o.reasons.join("; ")}` : o.status;
    rows.push([o.receivedAt, "order signed", o.participant, details, status, o.signature]);
  }
  for (const lot of listLots(store)) {
    for (const a of lot.approvals) rows.push([a.receivedAt, "lot approved", a.participant, `lot ${lot.id}`, "approved", a.signature]);
    if (lot.status === "settled" && lot.settledAt) rows.push([lot.settledAt, "lot settled on chain", "engine", `lot ${lot.id}`, "settled", lot.txHash ?? ""]);
  }
  return rows.sort((a, b) => a[0]!.localeCompare(b[0]!));
}

export function auditCsv(store: Store): string {
  return [HEADER, ...auditRows(store)].map((row) => row.map(cell).join(",")).join("\n") + "\n";
}

export function registerAuditRoutes(app: FastifyInstance, store: Store) {
  app.get("/audit.csv", async (_request, reply) =>
    reply
      .header("content-type", "text/csv; charset=utf-8")
      .header("content-disposition", 'attachment; filename="nexora-audit-trail.csv"')
      .send(auditCsv(store)),
  );
}
