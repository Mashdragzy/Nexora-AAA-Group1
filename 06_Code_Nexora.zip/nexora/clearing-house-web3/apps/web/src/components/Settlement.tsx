import { useEffect, useState } from "react";
import { createLot, getLots, type LotView as Lot } from "../api.ts";
import type { Addresses } from "./Accounts.tsx";
import { LotView } from "./LotView.tsx";

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

type Props = { addresses: Addresses; version: number; onChange: () => void };

// Step 6: the same engine, two modes. Netting settles every signed order of the day at
// once (only the net amounts move); instant settles the last signed order alone.
export function Settlement({ addresses, version, onChange }: Props) {
  const [lots, setLots] = useState<Lot[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    getLots().then(setLots).catch(() => setLots([]));
  }, [version]);

  async function build(mode: "netting" | "instant") {
    setError("");
    try {
      await createLot(today(), mode);
      onChange();
    } catch (e) {
      setError((e as Error).message);
    }
  }

  return (
    <div>
      <div className="actions">
        <button className="demo" onClick={() => build("netting")}>
          Settle cycle (netting)
        </button>
        <button className="demo" onClick={() => build("instant")}>
          Instant settle (last order)
        </button>
      </div>
      {error && <p className="notice bad">{error}</p>}
      {lots.length === 0 && <p className="muted">No lot yet. Sign at least two orders (step 4), then click “Settle cycle”.</p>}
      {[...lots].reverse().map((lot) => (
        <LotView key={lot.id} lot={lot} addresses={addresses} onChange={onChange} />
      ))}
    </div>
  );
}
