// The exact text that will be signed (and displayed on the Ledger screen). What you read is what you sign.
export function FlexPreview({ text, label = "Your Flex will show" }: { text: string; label?: string }) {
  return (
    <div className="flex-preview">
      <div className="label">{label}</div>
      {text}
    </div>
  );
}
