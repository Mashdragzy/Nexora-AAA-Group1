import { useEffect, useState } from "react";
import type { Address } from "viem";
import { PARTICIPANTS, type ParticipantKey } from "../ledger/accounts.ts";
import { useDmk } from "../ledger/dmk.tsx";
import { describeDeviceError } from "../ledger/errors.ts";
import { readAddress } from "../ledger/sign.ts";

export type Addresses = Partial<Record<ParticipantKey, Address>>;

// Reads the address of each participant. On a Ledger, each one is confirmed on the screen;
// with the demo accounts they are read at once.
export function Accounts({ addresses, onAddresses }: { addresses: Addresses; onAddresses: (a: Addresses) => void }) {
  const { signer } = useDmk();
  const [status, setStatus] = useState("");
  const done = PARTICIPANTS.filter((p) => addresses[p.key]).length;

  async function readAll() {
    if (!signer) return;
    const next: Addresses = {};
    for (const p of PARTICIPANTS) {
      try {
        if (signer.kind === "ledger") setStatus(`${p.name}: check the address on the Flex...`);
        next[p.key] = await readAddress(signer, p.path);
        onAddresses({ ...next });
      } catch (e) {
        setStatus(`${p.name}: ${describeDeviceError(e)}`);
        return;
      }
    }
    setStatus(signer.kind === "demo" ? "Three demo accounts ready. Next: sign a mandate in step 2." : "Three addresses read and confirmed on the device.");
  }

  // Demo accounts need no confirmation: read them as soon as the mode is chosen.
  useEffect(() => {
    if (signer?.kind === "demo" && done === 0) void readAll();
  }, [signer]); // readAll and done are recomputed each render; only a new signer should trigger this.

  return (
    <div>
      {signer?.kind !== "demo" && (
        <div className="actions">
          <button className="secondary" onClick={readAll} disabled={!signer}>
            Read the three addresses ({done}/3)
          </button>
        </div>
      )}
      {status && <p className="muted small">{status}</p>}
    </div>
  );
}
