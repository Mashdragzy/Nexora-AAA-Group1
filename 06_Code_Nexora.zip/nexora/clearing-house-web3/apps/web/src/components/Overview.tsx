import { AUDIT_CSV_URL, type ServerConfig } from "../api.ts";
import { cash, sideLabel, time, units } from "../format.ts";
import type { Dashboard } from "../useDashboard.ts";
import { GettingStarted } from "./GettingStarted.tsx";
import type { TabId } from "./Tabs.tsx";

type Props = { data: Dashboard; config: ServerConfig | null; signerReady: boolean; onGo: (tab: TabId) => void };

function pct(part: bigint, whole: bigint): number {
  return whole > 0n ? Number((part * 1000n) / whole) / 10 : 0;
}

// Landing screen: where the demo stands, the four-stage flow, the key figures,
// gross against net per lot and the latest events.
export function Overview({ data, config, signerReady, onGo }: Props) {
  const { mandates, orders, lots } = data;
  const accepted = orders.filter((o) => o.status !== "rejected");
  const refused = orders.filter((o) => o.status === "rejected");
  const fromAgent = orders.filter((o) => o.origin === "agent");
  const settled = lots.filter((l) => l.status === "settled");
  const netted = settled.filter((l) => l.mode === "netting");
  const gross = netted.reduce((s, l) => s + BigInt(l.gross.cash), 0n);
  const net = netted.reduce((s, l) => s + BigInt(l.net.cash), 0n);
  const last = [...settled].reverse().find((l) => l.delays);
  const approvals = lots.reduce((s, l) => s + l.approvals.length, 0);
  const signatures = mandates.length + orders.length + approvals;

  const steps = [
    { title: "Choose who signs", text: "Use the demo accounts (or a Ledger Flex) for Manager A, Manager B and Depositary C.", tab: "participants" as TabId, done: signerReady },
    { title: "Sign the rules", text: "Each manager signs a mandate: allowed fund, sides and a cash cap per day.", tab: "participants" as TabId, done: mandates.length >= 2 },
    { title: "Place orders", text: "Let the AI read an order email, or sign orders by hand: A subscribes 100 units, B redeems 40.", tab: "orders" as TabId, done: accepted.length >= 2 },
    { title: "Settle", text: "Net the day's orders and approve: only the difference moves, in one blockchain transaction.", tab: "settlement" as TabId, done: settled.length > 0 },
  ];

  const flow = [
    { n: 1, who: "AI agent", title: "Drafts", value: fromAgent.length, unit: "draft", text: "reads the order email and proposes fund, side and units" },
    { n: 2, who: "Code", title: "Checks", value: refused.length, unit: "refused", text: "compares each order with the manager's signed mandate", extra: `${accepted.length} accepted` },
    { n: 3, who: "Human", title: "Signs", value: signatures, unit: "signature", text: "mandates, orders and approvals, each signed explicitly" },
    { n: 4, who: "Blockchain", title: "Settles", value: settled.length, unit: "lot", text: "units against cash in one transaction (delivery versus payment)" },
  ];

  return (
    <div className="overview">
      <section className="hero panel">
        <div>
          <p className="eyebrow">Fund F · NAV {config ? cash(config.navPerUnit) : "..."} per unit · {config?.chainId === 31337 ? "local blockchain" : "testnet"}</p>
          <h2>From an order email to a settled trade, in seconds.</h2>
          <p className="muted">
            The AI drafts, the code checks, a human signs, the blockchain settles. A fooled or wrong AI can never move money on its own: every order must fit a mandate the manager signed.
          </p>
        </div>
        <button onClick={() => onGo(steps.find((s) => !s.done)?.tab ?? "settlement")}>{steps.every((s) => s.done) ? "See the settlement" : "Continue the demo →"}</button>
      </section>

      <section className="flow" aria-label="How an order flows">
        {flow.map((f) => (
          <div key={f.n} className={`flow-stage${f.value > 0 ? " live" : ""}`}>
            <div className="flow-top">
              <span className="flow-n">{f.n}</span>
              <span className="flow-who">{f.who}</span>
            </div>
            <div className="flow-title">{f.title}</div>
            <div className="flow-value">
              {f.value} <span>{f.unit}{f.value === 1 || f.unit === "refused" ? "" : "s"}</span>
            </div>
            <p className="small muted">{f.text}</p>
            {f.extra && <p className="small">{f.extra}</p>}
          </div>
        ))}
      </section>

      <section className="tiles" aria-label="Key figures">
        <div className="tile">
          <div className="k">Mandates signed</div>
          <div className="v">{mandates.length}</div>
          <div className="s">rules in force for today</div>
        </div>
        <div className="tile">
          <div className="k">Orders accepted</div>
          <div className="v">{accepted.length}</div>
          <div className="s">{fromAgent.length} drafted by the AI agent</div>
        </div>
        <div className="tile">
          <div className="k">Refused by a mandate</div>
          <div className="v">{refused.length}</div>
          <div className="s">never reach settlement</div>
        </div>
        <div className="tile highlight">
          <div className="k">Cash saved by netting</div>
          <div className="v">{netted.length ? `${pct(gross - net, gross)}%` : "n/a"}</div>
          <div className="s">{netted.length ? `${cash(gross)} gross, ${cash(net)} moved` : "after the first settlement"}</div>
        </div>
        <div className="tile">
          <div className="k">Order to settlement</div>
          <div className="v">{last?.delays ? `${last.delays.fromFirstOrder}s` : "n/a"}</div>
          <div className="s">instead of two business days (T+2)</div>
        </div>
      </section>

      <div className="two-col">
        <section className="panel">
          <div className="panel-head">
            <h2>Cash per lot: gross against net</h2>
            <div className="legend">
              <span><i className="sw gross" />Gross (order by order)</span>
              <span><i className="sw net" />Net (what moves)</span>
            </div>
          </div>
          <GrossNetChart lots={lots.filter((l) => l.mode === "netting")} />
          <LastLot lot={[...lots].reverse().find((l) => l.mode === "netting")} />
        </section>
        <section className="panel">
          <div className="panel-head">
            <h2>Latest activity</h2>
            <a className="btn-link" href={AUDIT_CSV_URL} download data-testid="audit-csv">
              Download the audit trail (CSV)
            </a>
          </div>
          <Activity data={data} />
        </section>
      </div>

      <GettingStarted steps={steps} onGo={onGo} />
    </div>
  );
}

// Horizontal bars, one pair per lot, scaled to the largest gross amount. Values are labelled
// directly; hovering a bar repeats its exact value.
function GrossNetChart({ lots }: { lots: Dashboard["lots"] }) {
  if (lots.length === 0) return <p className="muted empty">No netting lot yet. Once orders are signed, “Settle cycle” in the Settlement tab builds one.</p>;
  const max = lots.reduce((m, l) => (BigInt(l.gross.cash) > m ? BigInt(l.gross.cash) : m), 1n);
  const width = (v: string) => `${Math.max(0.5, pct(BigInt(v), max))}%`;
  return (
    <div className="chart" role="table" aria-label="Gross and net cash per lot">
      {lots.slice(-5).map((l) => (
        <div key={l.id} className="chart-row" role="row">
          <div className="chart-label" role="rowheader">
            Lot {l.id}
            <span className="muted small"> {pct(BigInt(l.gross.cash) - BigInt(l.net.cash), BigInt(l.gross.cash))}% saved</span>
          </div>
          <div className="bars">
            <div className="bar-line" role="cell">
              <div className="bar gross" style={{ width: width(l.gross.cash) }} title={`Gross ${cash(l.gross.cash)}`} />
              <span className="bar-val">{cash(l.gross.cash)}</span>
            </div>
            <div className="bar-line" role="cell">
              <div className="bar net" style={{ width: width(l.net.cash) }} title={`Net ${cash(l.net.cash)}`} />
              <span className="bar-val">{cash(l.net.cash)}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// Who receives and who delivers in the latest netting lot: the fund only covers the difference.
function LastLot({ lot }: { lot: Dashboard["lots"][number] | undefined }) {
  if (!lot) return null;
  const name = (address: string) => (address.toLowerCase() === lot.fund.toLowerCase() ? lot.fundName : (lot.names?.[address.toLowerCase()] ?? "Participant"));
  return (
    <div className="last-lot">
      <h3>
        Inside lot {lot.id} <span className="muted small">({lot.status === "settled" ? "settled" : "approvals pending"})</span>
      </h3>
      <table>
        <thead>
          <tr>
            <th>Participant</th>
            <th className="num">Units</th>
            <th className="num">Cash</th>
          </tr>
        </thead>
        <tbody>
          {lot.positions.map((p) => (
            <tr key={p.participant}>
              <td>
                <strong>{name(p.participant)}</strong>
              </td>
              <td className="num">{BigInt(p.shares) < 0n ? `delivers ${units(p.shares)}` : `receives ${units(p.shares)}`}</td>
              <td className="num">{BigInt(p.cash) < 0n ? `pays ${cash(p.cash)}` : `receives ${cash(p.cash)}`}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p className="small muted">The fund line is the net of all orders: only this difference is created or redeemed.</p>
    </div>
  );
}

type Event ={ at: string; text: string; tone: "ok" | "bad" | "accent" };

function Activity({ data }: { data: Dashboard }) {
  const events: Event[] = [];
  for (const m of data.mandates) events.push({ at: m.receivedAt, text: `${m.participantName} signed a mandate (cap ${cash(m.maxCashPerCycle)} per day)`, tone: "accent" });
  for (const o of data.orders) {
    const what = `${o.participantName}: ${sideLabel(o.side).toLowerCase()} ${units(o.shares)} units of ${o.fundName}${o.origin === "agent" ? " (drafted by the AI)" : ""}`;
    events.push({ at: o.receivedAt, text: o.status === "rejected" ? `${what}, refused by the mandate` : what, tone: o.status === "rejected" ? "bad" : "accent" });
  }
  for (const l of data.lots) {
    for (const a of l.approvals) events.push({ at: a.receivedAt, text: `${l.names?.[a.participant.toLowerCase()] ?? "A participant"} approved lot ${l.id}`, tone: "accent" });
    const lastApproval = l.approvals.at(-1)?.receivedAt;
    if (l.status === "settled" && lastApproval) events.push({ at: lastApproval, text: `Lot ${l.id} settled: ${cash(l.net.cash)} moved on chain instead of ${cash(l.gross.cash)}`, tone: "ok" });
  }
  events.sort((a, b) => b.at.localeCompare(a.at));
  if (events.length === 0) return <p className="muted empty">Nothing yet. Start with the Participants tab.</p>;
  return (
    <ul className="activity">
      {events.slice(0, 7).map((e, i) => (
        <li key={i} className={e.tone}>
          <span className="dot" />
          <span className="when">{time(e.at)}</span>
          <span>{e.text}</span>
        </li>
      ))}
    </ul>
  );
}
