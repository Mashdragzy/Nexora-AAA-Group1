import { useEffect, useState } from "react";
import { explainRefusal } from "@chw3/engine";
import { getBench, runBench, type BenchCase, type BenchResult, type ServerConfig, type Verdict } from "../api.ts";
import { sideLabel, units } from "../format.ts";
import { Badge } from "./Badge.tsx";

const VERDICT_TONE: Record<Verdict, "ok" | "accent" | "warn" | "bad"> = {
  "as expected": "ok",
  "caught by the mandate": "accent",
  "safe: nothing drafted": "warn",
  unsafe: "bad",
};

function expected(c: BenchCase): string {
  return c.legit ? `${sideLabel(c.legit.side)} ${c.legit.units} units for ${c.legit.participantName}` : "no order";
}

// AI test bench: synthetic emails (clear, ambiguous and trapped, in English and French) run one at a
// time through the real agent, then through the signed mandate. The score shows that nothing
// unsafe ever comes out, whether the model resists the trap or the code stops it.
export function BenchPanel({ config }: { config: ServerConfig | null }) {
  const [cases, setCases] = useState<BenchCase[]>([]);
  const [results, setResults] = useState<Record<string, BenchResult | { error: string }>>({});
  const [running, setRunning] = useState<string | null>(null);
  const [open, setOpen] = useState<string | null>(null);

  useEffect(() => {
    getBench().then(setCases).catch(() => setCases([]));
  }, []);

  async function run(id: string) {
    setRunning(id);
    try {
      const result = await runBench(id);
      setResults((r) => ({ ...r, [id]: result }));
    } catch (e) {
      setResults((r) => ({ ...r, [id]: { error: (e as Error).message } }));
    } finally {
      setRunning(null);
    }
  }

  const done = Object.values(results).filter((r): r is BenchResult => "verdict" in r);
  const count = (v: Verdict) => done.filter((r) => r.verdict === v).length;
  const agentOff = config?.agentKeySource === "none";

  return (
    <div>
      {agentOff && <p className="notice warn">The AI agent is off: add a free OpenRouter key to .env to run the bench. The cases and their emails can still be read.</p>}
      <div className="bench-score" data-testid="bench-score">
        <div>
          <span className="k">Cases run</span>
          <span className="v">
            {done.length} / {cases.length}
          </span>
        </div>
        <div>
          <span className="k">As expected</span>
          <span className="v ok">{count("as expected")}</span>
        </div>
        <div>
          <span className="k">Caught by the mandate</span>
          <span className="v accent">{count("caught by the mandate")}</span>
        </div>
        <div>
          <span className="k">Nothing drafted</span>
          <span className="v">{count("safe: nothing drafted")}</span>
        </div>
        <div>
          <span className="k">Unsafe</span>
          <span className="v bad">{count("unsafe")}</span>
        </div>
      </div>
      <p className="small muted">
        Each run is one call to the free model. Sign the mandates of Manager A and Manager B first (Participants tab) so that the mandate check is meaningful.
      </p>
      <table className="bench">
        <thead>
          <tr>
            <th>Email</th>
            <th>Threat</th>
            <th>Legitimate order</th>
            <th>Result</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {cases.map((c) => {
            const r = results[c.id];
            return (
              <tr key={c.id}>
                <td className="wrap">
                  <Badge>{c.language}</Badge> <strong>{c.title}</strong>
                  <div>
                    <button className="link small" onClick={() => setOpen(open === c.id ? null : c.id)}>
                      {open === c.id ? "Hide the email" : "Read the email"}
                    </button>
                  </div>
                  {open === c.id && <pre className="log">{c.email}</pre>}
                </td>
                <td className="wrap small">{c.threat}</td>
                <td className="small">{expected(c)}</td>
                <td className="wrap small" data-testid={`bench-result-${c.id}`}>
                  {!r && <span className="muted">not run yet</span>}
                  {r && "error" in r && <span className="bad-text">{r.error}</span>}
                  {r && "verdict" in r && (
                    <>
                      <Badge tone={VERDICT_TONE[r.verdict]}>{r.verdict}</Badge>
                      <div>
                        {r.draft ? `Agent drafted: ${sideLabel(r.draft.side)} ${units(r.draft.shares)} units for ${r.draft.participantName}.` : "Agent drafted nothing."}
                      </div>
                      {r.check && <div className={r.check.ok ? "ok-text" : "bad-text"}>{r.check.ok ? "Mandate check: inside the signed mandate." : `Mandate check: ${r.check.reasons.map(explainRefusal).join(" ")}`}</div>}
                      <div className="muted">{r.explanation}</div>
                    </>
                  )}
                </td>
                <td>
                  <button className="secondary" onClick={() => run(c.id)} disabled={running !== null || agentOff}>
                    {running === c.id ? "Running..." : r ? "Run again" : "Run"}
                  </button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
