import type { TabId } from "./Tabs.tsx";

type Step = { title: string; text: string; tab: TabId; done: boolean };

// The four steps of the demo, each with a button that opens the right tab.
export function GettingStarted({ steps, onGo }: { steps: Step[]; onGo: (tab: TabId) => void }) {
  return (
    <section className="guide panel" aria-label="Getting started">
      <div className="panel-head">
        <div>
          <h2>First time here? Four steps, about two minutes.</h2>
          <p className="muted small">Follow them in order. Each step opens the right tab; the overview updates as you go.</p>
        </div>
      </div>
      <ol className="guide-steps">
        {steps.map((s, i) => (
          <li key={s.title} className={s.done ? "done" : ""}>
            <span className="guide-num">{s.done ? "✓" : i + 1}</span>
            <div>
              <strong>{s.title}</strong>
              <p className="small muted">{s.text}</p>
              <button className="link" onClick={() => onGo(s.tab)}>
                Open →
              </button>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
