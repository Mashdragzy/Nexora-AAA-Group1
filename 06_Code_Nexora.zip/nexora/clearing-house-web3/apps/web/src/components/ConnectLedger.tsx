import { useDmk } from "../ledger/dmk.tsx";
import { DEMO_SIGNER_AVAILABLE } from "../ledger/demo.ts";

// Step 1: choose who signs. A Ledger Flex (real hardware signatures) or, on the local
// demo chain, three test accounts that sign instantly in the browser.
export function ConnectLedger() {
  const { signer, connecting, error, connect, useDemoAccounts } = useDmk();

  if (signer?.kind === "demo") {
    return <p className="notice ok">Demo accounts active: Manager A, Manager B and Depositary C sign in the browser. No Ledger needed.</p>;
  }
  if (signer?.kind === "ledger") {
    return <p className="notice ok">Ledger Flex connected, Ethereum app open.</p>;
  }

  return (
    <div>
      <div className="actions">
        {DEMO_SIGNER_AVAILABLE && (
          <button onClick={useDemoAccounts} data-testid="use-demo">
            Use demo accounts (no Ledger needed)
          </button>
        )}
        <button className={DEMO_SIGNER_AVAILABLE ? "secondary" : ""} onClick={connect} disabled={connecting}>
          {connecting ? "Looking for the device..." : "Connect a Ledger Flex"}
        </button>
      </div>
      {error && <p className="notice bad">{error}</p>}
      <p className="muted small">
        {DEMO_SIGNER_AVAILABLE
          ? "First time? Click “Use demo accounts”. To sign on a real Ledger Flex: Chrome only, close Ledger Wallet first."
          : "Chrome only. Close Ledger Wallet first, otherwise the browser cannot see the device."}
      </p>
    </div>
  );
}
