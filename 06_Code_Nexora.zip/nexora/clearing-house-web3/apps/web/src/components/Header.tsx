import type { ServerConfig } from "../api.ts";
import { useDmk } from "../ledger/dmk.tsx";
import { Badge } from "./Badge.tsx";

const NETWORKS: Record<number, string> = { 84532: "Base Sepolia", 31337: "Local anvil" };

const KEY_SOURCE = {
  "key-ring": { tone: "ok" as const, label: "AI agent: on (key in Ledger Key Ring)" },
  env: { tone: "ok" as const, label: "AI agent: on" },
  none: { tone: "warn" as const, label: "AI agent: off (no key)" },
};

export function Header({ config }: { config: ServerConfig | null }) {
  const { signer, connecting } = useDmk();
  const network = config ? (NETWORKS[config.chainId] ?? `Chain ${config.chainId}`) : "Server offline";
  return (
    <header className="header">
      <div className="brand">
        <span className="logo" aria-hidden="true">N</span>
        <div>
          <h1>
            Nexora <span className="subtitle">settlement engine for tokenized funds</span>
          </h1>
          <p className="tagline">Fund orders settled in seconds. The AI drafts, the code checks, a human signs, the blockchain settles.</p>
        </div>
      </div>
      <div className="status">
        <Badge tone={config ? "accent" : "bad"}>{network}</Badge>
        <Badge tone={signer ? "ok" : "muted"}>{signer?.kind === "demo" ? "Signer: demo accounts" : signer ? "Signer: Ledger Flex" : connecting ? "Signer: connecting" : "Signer: not chosen"}</Badge>
        {config && <Badge tone={KEY_SOURCE[config.agentKeySource].tone}>{KEY_SOURCE[config.agentKeySource].label}</Badge>}
      </div>
    </header>
  );
}
