export type TabId = "overview" | "participants" | "orders" | "settlement" | "bench";

export type TabItem = { id: TabId; label: string; note?: string; done?: boolean };

// Navigation between the four screens of the dashboard.
export function Tabs({ items, current, onChange }: { items: TabItem[]; current: TabId; onChange: (tab: TabId) => void }) {
  return (
    <nav className="tabs" aria-label="Sections">
      {items.map((t) => (
        <button key={t.id} role="tab" aria-selected={t.id === current} data-testid={`tab-${t.id}`} className={`tab${t.id === current ? " active" : ""}`} onClick={() => onChange(t.id)}>
          {t.label}
          {t.note && <span className={`tab-note${t.done ? " done" : ""}`}>{t.note}</span>}
        </button>
      ))}
    </nav>
  );
}
