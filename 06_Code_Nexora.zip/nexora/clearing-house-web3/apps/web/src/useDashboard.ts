import { useEffect, useState } from "react";
import { getInstructions, getLots, getMandates, type LotView, type StoredInstruction, type StoredMandate } from "./api.ts";

export type Dashboard = { mandates: StoredMandate[]; orders: StoredInstruction[]; lots: LotView[] };

const POLL_MS = 4000;

// Everything the overview and the tab counters show. Reloads after each signature
// (version) and every few seconds, so the overview stays live while the demo runs.
export function useDashboard(version: number): Dashboard {
  const [data, setData] = useState<Dashboard>({ mandates: [], orders: [], lots: [] });

  useEffect(() => {
    let stopped = false;
    const load = () =>
      Promise.all([getMandates(), getInstructions(), getLots()])
        .then(([mandates, orders, lots]) => !stopped && setData({ mandates, orders, lots }))
        .catch(() => undefined);
    load();
    const timer = setInterval(load, POLL_MS);
    return () => {
      stopped = true;
      clearInterval(timer);
    };
  }, [version]);

  return data;
}
