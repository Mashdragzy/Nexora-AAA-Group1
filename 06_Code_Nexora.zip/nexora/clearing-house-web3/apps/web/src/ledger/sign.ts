import { DeviceActionStatus, type DeviceActionState } from "@ledgerhq/device-management-kit";
import { pad, serializeSignature, type Address, type Hex } from "viem";
import type { Observable } from "rxjs";
import type { AppSigner } from "./dmk.tsx";
import { demoAccount } from "./demo.ts";

type DeviceAction<Output> = { observable: Observable<DeviceActionState<Output, unknown, unknown>> };

// Ledger returns v as 0 or 1 on some firmwares; Ethereum signatures expect 27 or 28.
const V_OFFSET = 27;

// Waits for a Ledger device action. onPending fires when the Flex needs the user.
function runDeviceAction<Output>(action: DeviceAction<Output>, onPending?: () => void): Promise<Output> {
  return new Promise((resolve, reject) => {
    const sub = action.observable.subscribe({
      next: (state) => {
        if (state.status === DeviceActionStatus.Pending) onPending?.();
        if (state.status === DeviceActionStatus.Completed) {
          sub.unsubscribe();
          resolve(state.output);
        }
        if (state.status === DeviceActionStatus.Error) {
          sub.unsubscribe();
          reject(state.error);
        }
      },
      error: reject,
    });
  });
}

// Address of a derivation path. On a Ledger it is shown and confirmed on the screen.
export async function readAddress(signer: AppSigner, path: string, onPending?: () => void): Promise<Address> {
  if (signer.kind === "demo") return demoAccount(path).address;
  const output = await runDeviceAction(signer.eth.getAddress(path, { checkOnDevice: true }), onPending);
  return output.address as Address;
}

// Signs a human-readable text (EIP-191 "personal_sign"). The server checks the same text
// with viem's verifyMessage, so what is displayed is exactly what is signed.
export async function signText(signer: AppSigner, path: string, text: string, onPending?: () => void): Promise<Hex> {
  if (signer.kind === "demo") return demoAccount(path).signMessage({ message: text });
  const { r, s, v } = await runDeviceAction(signer.eth.signMessage(path, text), onPending);
  return serializeSignature({
    r: pad(r),
    s: pad(s),
    v: BigInt(v >= V_OFFSET ? v : v + V_OFFSET),
  });
}
