import { privateKeyToAccount, type PrivateKeyAccount } from "viem/accounts";

// Demo signer: lets anyone run the full flow on a local chain without a Ledger Flex.
//
// The three keys below are anvil's public test accounts 2, 3 and 4 (default mnemonic
// "test test ... junk"). They are printed by anvil at every start, hold no real value
// and only exist on the local chain started by `npm run demo:easy`.
// The page offers this mode only when the launcher sets VITE_DEMO_SIGNER=1.
const DEMO_KEYS: Record<string, `0x${string}`> = {
  "44'/60'/0'/0/0": "0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a", // Manager A
  "44'/60'/1'/0/0": "0x7c852118294e51e653712a81e05800f419141751be58f605c371e15141b007a6", // Manager B
  "44'/60'/2'/0/0": "0x47e179ec197488593b187f80a00eb0da91f1b9d0b13f8733639f19c30a34926a", // Depositary C
};

export const DEMO_SIGNER_AVAILABLE = import.meta.env.VITE_DEMO_SIGNER === "1";

export function demoAccount(path: string): PrivateKeyAccount {
  const key = DEMO_KEYS[path];
  if (!key) throw new Error(`No demo account for path ${path}`);
  return privateKeyToAccount(key);
}
