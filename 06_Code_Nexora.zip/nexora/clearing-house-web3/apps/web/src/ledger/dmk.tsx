import { createContext, useContext, useState, type ReactNode } from "react";
import { ConsoleLogger, DeviceManagementKitBuilder, type DeviceManagementKit } from "@ledgerhq/device-management-kit";
import { webHidTransportFactory } from "@ledgerhq/device-transport-kit-web-hid";
import { SignerEthBuilder, type SignerEth } from "@ledgerhq/device-signer-kit-ethereum";

// Who signs in this session: a Ledger Flex over WebHID, or the local demo accounts.
export type AppSigner = { kind: "ledger"; eth: SignerEth } | { kind: "demo" };

type SignerContextValue = {
  signer: AppSigner | null;
  connecting: boolean;
  error: string | null;
  connect: () => void;
  useDemoAccounts: () => void;
};

const SignerContext = createContext<SignerContextValue | null>(null);

// Without a partner origin token the Ledger signer still works: the Flex shows the plain
// text of each message, which is all this app needs.
const ORIGIN_TOKEN = import.meta.env.VITE_LEDGER_ORIGIN_TOKEN || "nexora";

function buildDmk(): DeviceManagementKit {
  return new DeviceManagementKitBuilder().addLogger(new ConsoleLogger()).addTransport(webHidTransportFactory).build();
}

// One Ledger Device Management Kit instance for the whole page, owned by this provider.
export function DmkProvider({ children }: { children: ReactNode }) {
  const [dmk] = useState(buildDmk);
  const [signer, setSigner] = useState<AppSigner | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function connect() {
    setConnecting(true);
    setError(null);
    const sub = dmk.startDiscovering({}).subscribe({
      next: async (device) => {
        sub.unsubscribe();
        const sessionId = await dmk.connect({ device });
        setSigner({ kind: "ledger", eth: new SignerEthBuilder({ dmk, sessionId, originToken: ORIGIN_TOKEN }).build() });
        setConnecting(false);
      },
      error: (e) => {
        setError("Could not find the Ledger: " + String(e));
        setConnecting(false);
      },
    });
  }

  function useDemoAccounts() {
    setError(null);
    setSigner({ kind: "demo" });
  }

  return <SignerContext.Provider value={{ signer, connecting, error, connect, useDemoAccounts }}>{children}</SignerContext.Provider>;
}

export function useDmk(): SignerContextValue {
  const value = useContext(SignerContext);
  if (!value) throw new Error("useDmk needs a DmkProvider");
  return value;
}

// Short label used in buttons and messages: "on the Flex" or "with the demo account".
export function signerWord(signer: AppSigner | null): string {
  return signer?.kind === "demo" ? "with the demo account" : "on the Flex";
}
