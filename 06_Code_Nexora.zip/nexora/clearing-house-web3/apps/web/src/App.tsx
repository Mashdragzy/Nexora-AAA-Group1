import { useEffect, useState } from "react";
import "./App.css";
import { getConfig, type ServerConfig } from "./api.ts";
import { DmkProvider, useDmk } from "./ledger/dmk.tsx";
import { Header } from "./components/Header.tsx";
import { Tabs, type TabId } from "./components/Tabs.tsx";
import { Overview } from "./components/Overview.tsx";
import { ConnectLedger } from "./components/ConnectLedger.tsx";
import { Accounts, type Addresses } from "./components/Accounts.tsx";
import { MandatesPanel } from "./components/MandatesPanel.tsx";
import { MandateForm } from "./components/MandateForm.tsx";
import { IntakePanel, type DraftForForm } from "./components/IntakePanel.tsx";
import { InstructionForm } from "./components/InstructionForm.tsx";
import { OrdersTable } from "./components/OrdersTable.tsx";
import { Settlement } from "./components/Settlement.tsx";
import { BenchPanel } from "./components/BenchPanel.tsx";
import { useDashboard } from "./useDashboard.ts";

type CardProps = { step: number; title: string; hint: string; wide?: boolean; children: React.ReactNode };

// One numbered block, with a one-line explanation of what happens in it.
function Card({ step, title, hint, wide, children }: CardProps) {
  return (
    <section className={`card${wide ? " wide" : ""}`}>
      <h2>
        <span className="step">{step}</span>
        {title}
      </h2>
      <p className="hint">{hint}</p>
      {children}
    </section>
  );
}

function Next({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <div className="next">
      <button onClick={onClick}>{label} →</button>
    </div>
  );
}

const CONFIG_RETRY_MS = 2000;

export default function App() {
  return (
    <DmkProvider>
      <Dashboard />
    </DmkProvider>
  );
}

// Four tabs: overview, participants and mandates, orders (AI intake and signing), settlement.
// Every tab stays mounted (only hidden), so drafts and forms keep their state when switching.
function Dashboard() {
  const { signer } = useDmk();
  const [tab, setTab] = useState<TabId>("overview");
  const [addresses, setAddresses] = useState<Addresses>({});
  const [config, setConfig] = useState<ServerConfig | null>(null);
  const [draft, setDraft] = useState<DraftForForm | null>(null);
  const [version, setVersion] = useState(0);
  const [serverError, setServerError] = useState("");
  const data = useDashboard(version);

  // The page is often opened before the server is ready: keep trying until it answers.
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    let stopped = false;
    const load = () =>
      getConfig()
        .then((c) => {
          setConfig(c);
          setServerError("");
        })
        .catch(() => {
          setServerError("Waiting for the Nexora server (it starts with the launcher). Retrying every 2 seconds...");
          if (!stopped) timer = setTimeout(load, CONFIG_RETRY_MS);
        });
    load();
    return () => {
      stopped = true;
      clearTimeout(timer);
    };
  }, []);

  // Any signature or settlement bumps the version so every panel reloads its data.
  const refresh = () => setVersion((v) => v + 1);
  const go = (next: TabId) => {
    setTab(next);
    window.scrollTo({ top: 0 });
  };

  // When the AI drafts an order, the signing form next to it is filled in.
  const onDraft = (d: DraftForForm | null) => setDraft(d);

  const accepted = data.orders.filter((o) => o.status !== "rejected").length;
  const settled = data.lots.filter((l) => l.status === "settled").length;
  const tabs = [
    { id: "overview" as const, label: "Overview" },
    { id: "participants" as const, label: "Participants", note: `${data.mandates.length} mandate${data.mandates.length === 1 ? "" : "s"}`, done: data.mandates.length >= 2 },
    { id: "orders" as const, label: "Orders and AI agent", note: `${data.orders.length} order${data.orders.length === 1 ? "" : "s"}`, done: accepted >= 2 },
    { id: "settlement" as const, label: "Settlement", note: `${settled} settled`, done: settled > 0 },
    { id: "bench" as const, label: "AI test bench", note: "8 emails" },
  ];

  return (
    <>
      <Header config={config} />
      <Tabs items={tabs} current={tab} onChange={go} />
      {serverError && <p className="notice warn">{serverError}</p>}

      <main>
        <div hidden={tab !== "overview"}>
          <Overview data={data} config={config} signerReady={Boolean(signer)} onGo={go} />
        </div>

        <div hidden={tab !== "participants"} className="grid">
          <Card step={1} title="Who signs" hint="Each decision is signed by a person: on a Ledger Flex, or with the demo accounts on the local chain.">
            <ConnectLedger />
            <Accounts addresses={addresses} onAddresses={setAddresses} />
          </Card>
          <Card step={2} title="Participants and their mandates" hint="A mandate is the rule a manager signs once: allowed fund, sides and a cash cap per day.">
            <MandatesPanel config={config} addresses={addresses} version={version} />
            <details>
              <summary>Sign a mandate</summary>
              <MandateForm addresses={addresses} onSigned={refresh} />
            </details>
          </Card>
          <Next label="Next: place orders" onClick={() => go("orders")} />
        </div>

        <div hidden={tab !== "orders"} className="grid">
          <Card step={3} title="AI order intake" hint="The AI agent reads an order email and drafts it. It cannot sign or compute amounts: the code checks its draft.">
            <IntakePanel config={config} onDraft={onDraft} />
          </Card>
          <Card step={4} title="Sign an order" hint="Pick a manager, a side and a number of units, then sign. The text below is exactly what gets signed.">
            <InstructionForm config={config} addresses={addresses} draft={draft} onSigned={refresh} />
          </Card>
          <Card step={5} title="Orders" hint="Every signed order, its mandate check and its path to settlement." wide>
            <OrdersTable version={version} />
          </Card>
          <Next label="Next: settle the day" onClick={() => go("settlement")} />
        </div>

        <div hidden={tab !== "settlement"} className="grid">
          <Card step={6} title="Settlement, gross against net" hint="Netting offsets buys and sells of the day: the fund only moves the difference, in one blockchain transaction." wide>
            <Settlement addresses={addresses} version={version} onChange={refresh} />
          </Card>
          <Next label="Back to the overview" onClick={() => go("overview")} />
        </div>

        <div hidden={tab !== "bench"} className="grid">
          <Card step={7} title="AI test bench (red team)" hint="Eight synthetic emails, clear, ambiguous and trapped, in English and French. Each one goes through the real agent, then the signed mandate: nothing unsafe should ever come out." wide>
            <BenchPanel config={config} />
          </Card>
        </div>
      </main>
    </>
  );
}
